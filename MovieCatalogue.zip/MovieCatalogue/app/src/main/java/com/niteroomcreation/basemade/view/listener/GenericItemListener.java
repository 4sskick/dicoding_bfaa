package com.niteroomcreation.basemade.view.listener;

/**
 * Created by Septian Adi Wijaya on 01/10/19
 */
public interface GenericItemListener<T> {
    void onItemClicked(T item);
}
