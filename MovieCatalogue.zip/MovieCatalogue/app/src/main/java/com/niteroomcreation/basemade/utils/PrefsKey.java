package com.niteroomcreation.basemade.utils;

/**
 * Created by Septian Adi Wijaya on 21/02/2020.
 * please be sure to add credential if you use people's code
 */
public class PrefsKey {

    public static final String KEY_REMINDER_RELEASE = "KEY_REMINDER_RELEASE".toLowerCase();
    public static final String KEY_REMINDER_DAILY = "KEY_REMINDER_DAILY".toLowerCase();

    public static final String KEY_FCM_TOKEN = "key_token_fcm";
}
