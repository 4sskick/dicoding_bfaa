package com.niteroomcreation.basemade;


import android.app.Application;

/**
 * Created by Septian Adi Wijaya on 30/09/19
 */
public class CustomApplication extends Application {

    @Override
    public void onCreate() {
        super.onCreate();


    }
}