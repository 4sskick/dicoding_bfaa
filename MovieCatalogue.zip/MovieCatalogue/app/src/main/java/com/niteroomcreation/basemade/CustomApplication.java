package com.niteroomcreation.basemade;


import android.support.multidex.MultiDexApplication;

/**
 * Created by Septian Adi Wijaya on 30/09/19
 */
public class CustomApplication extends MultiDexApplication {

    @Override
    public void onCreate() {
        super.onCreate();


    }
}