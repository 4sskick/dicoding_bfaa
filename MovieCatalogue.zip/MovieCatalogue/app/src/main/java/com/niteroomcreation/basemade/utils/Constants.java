package com.niteroomcreation.basemade.utils;

/**
 * Created by Septian Adi Wijaya on 17/12/19
 */
public class Constants {

    public static final String EXTRA_ARR_MODEL = "extra.put.arr.model.state";
    public static final String EXTRA_LANG_MODEL = "extra.put.lang.model.state";
}
