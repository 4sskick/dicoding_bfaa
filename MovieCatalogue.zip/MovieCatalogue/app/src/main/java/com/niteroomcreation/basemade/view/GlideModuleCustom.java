package com.niteroomcreation.basemade.view;

import com.bumptech.glide.annotation.GlideModule;
import com.bumptech.glide.module.AppGlideModule;

/**
 * Created by Septian Adi Wijaya on 05/11/19
 */

@GlideModule
public class GlideModuleCustom extends AppGlideModule {
}
