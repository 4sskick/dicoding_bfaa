package com.niteroomcreation.basemade.base;

/**
 * Created by Septian Adi Wijaya on 04/10/19
 */
public interface IBaseDialogView extends IBaseView {
    void onDismissDialog(String dialogTag);
}
